package com.ood.employeeService.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "AttendenceTypes")
public class AttendenceTypes {
    
    @Id
    @Column(name = "AttendenceId")
    private int AttendenceId;
    
    @Column(name = "AttendenceType")
    private String AttendenceType;
    
    @Column(name = "DWPoints")
    private int DWpoints;

    // Constructors, getters, and setters
    public AttendenceTypes() {}

	public AttendenceTypes(int attendenceId, String attendenceType, int dWpoints) {
		super();
		AttendenceId = attendenceId;
		AttendenceType = attendenceType;
		DWpoints = dWpoints;
	}

	public int getAttendenceId() {
		return AttendenceId;
	}

	public void setAttendenceId(int attendenceId) {
		AttendenceId = attendenceId;
	}

	public String getAttendenceType() {
		return AttendenceType;
	}

	public void setAttendenceType(String attendenceType) {
		AttendenceType = attendenceType;
	}

	public int getDWpoints() {
		return DWpoints;
	}

	public void setDWpoints(int dWpoints) {
		DWpoints = dWpoints;
	}

 

 
}
