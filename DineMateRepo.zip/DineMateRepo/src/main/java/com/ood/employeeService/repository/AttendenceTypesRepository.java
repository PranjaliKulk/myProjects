package com.ood.employeeService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ood.employeeService.model.AttendenceTypes;

public interface AttendenceTypesRepository extends JpaRepository<AttendenceTypes, Integer>{

}
