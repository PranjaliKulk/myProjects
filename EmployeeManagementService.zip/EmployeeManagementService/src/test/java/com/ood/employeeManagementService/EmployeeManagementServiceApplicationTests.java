package com.ood.employeeManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
